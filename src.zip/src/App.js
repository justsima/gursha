import SignIn from "./pages/signin";
import { ThemeProvider } from "@mui/material/styles";
import { theme } from "./theme";
import { useState } from "react";
import Dashboard from "./pages/Dashboard";
import AddInventory from "./pages/Inventory";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import NotFound from "./pages/404";

const App = (props) => {
  return (
    <div className="w-[100vw]">
      <ThemeProvider theme={theme}>
        <Router>
          <Routes>
            <Route path="/" element={<SignIn />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/Inventory" element={<AddInventory/>}/>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Router>
      </ThemeProvider>
    </div>
  );
};

export default App;
