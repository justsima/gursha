import {DashboardLayout} from "../components/dashboard-layout";
const Dashboard = ()=>{
    return(
        <DashboardLayout>
            <div>
                dashboard
            </div>
        </DashboardLayout>
    )
}
export default Dashboard